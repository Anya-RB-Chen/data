import os
import json

data = []

for file in os.listdir('.'):
    # print(file)
    if file.endswith('.json'):
        with open(file, 'r') as f:
            # append each dict object in json file to data list
            temp = json.loads(f.read())
            for item in temp:
                data.append(item)
            print('File: {} has been processed'.format(file))
            print('Number of items in file: {}'.format(len(temp)))

print(len(data))

# Save the list into json file
with open('../staff.json', 'w') as f:
    json.dump(data, f, indent=4)